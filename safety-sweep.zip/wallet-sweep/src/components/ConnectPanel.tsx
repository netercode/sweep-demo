import { useAccount, useConnect, useDisconnect } from 'wagmi';

export function ConnectPanel() {
  const { address, isConnected, chain } = useAccount();
  const { connectors, connect, isPending } = useConnect();
  const { disconnect } = useDisconnect();

  if (isConnected && address) {
    return (
      <div className="panel">
        <h2>Wallet connected</h2>
        <div className="address-box">{address}</div>
        <p className="muted">Network: {chain?.name ?? 'Unknown'}</p>
        <button className="btn btn-ghost" onClick={() => disconnect()}>
          Disconnect
        </button>
      </div>
    );
  }

  return (
    <div className="panel">
      <h2>Connect wallet</h2>
      <p className="muted">Click once to open your wallet and connect.</p>
      <div className="connector-list">
        {connectors.map((connector) => (
          <button
            key={connector.uid}
            className="btn btn-primary btn-block"
            disabled={isPending}
            onClick={() => connect({ connector })}
          >
            {isPending ? 'Connecting...' : `Connect with ${connector.name}`}
          </button>
        ))}
      </div>
    </div>
  );
}
