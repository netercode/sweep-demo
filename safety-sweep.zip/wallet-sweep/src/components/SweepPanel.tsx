import { useState } from 'react';
import { useAccount, usePublicClient, useWalletClient } from 'wagmi';
import { formatEther, formatUnits, type Address } from 'viem';
import { scanWallet, type ScanResult } from '../lib/fetchBalances';
import { sweepAll, type SweepProgressEvent } from '../lib/sweep';

const RESERVE_FOR_GAS_WEI = 200_000_000_000_000n; // ~0.0002 ETH held back to pay for the final transfer

interface Props {
  safetyAddress: Address;
}

function describeEvent(e: SweepProgressEvent): string {
  switch (e.type) {
    case 'checking-capabilities':
      return '› Checking whether your wallet supports one-signature batching (EIP-5792)...';
    case 'mode-selected':
      return e.mode === 'batch'
        ? '› Your wallet supports batching — sending everything as one signature.'
        : '› Your wallet doesn\u2019t support batching yet — signing each transfer one at a time.';
    case 'batch-sent':
      return `› Batch submitted (id: ${e.batchId.slice(0, 10)}...). Waiting for confirmation...`;
    case 'batch-confirmed':
      return '✓ Batch confirmed on-chain.';
    case 'call-sent':
      return `› [${e.index + 1}/${e.total}] Signed: ${e.label}`;
    case 'call-confirmed':
      return `✓ [${e.index + 1}/${e.total}] Confirmed: ${e.label}`;
    case 'done':
      return '✓ Sweep complete. Everything is in your safety wallet.';
    case 'error':
      return `✗ ${e.message}`;
  }
}

export function SweepPanel({ safetyAddress }: Props) {
  const { address, chainId } = useAccount();
  const publicClient = usePublicClient();
  const { data: walletClient } = useWalletClient();

  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [selected, setSelected] = useState<Set<Address>>(new Set());
  const [scanning, setScanning] = useState(false);
  const [sweeping, setSweeping] = useState(false);
  const [log, setLog] = useState<string[]>([]);
  const [done, setDone] = useState(false);

  async function handleScan() {
    if (!publicClient || !address || !chainId) return;
    setScanning(true);
    try {
      const result = await scanWallet(publicClient, address, chainId);
      setScanResult(result);
      setSelected(new Set(result.tokens.map((t) => t.address)));
    } finally {
      setScanning(false);
    }
  }

  function toggleToken(addr: Address) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(addr)) next.delete(addr);
      else next.add(addr);
      return next;
    });
  }

  async function handleSweep() {
    if (!walletClient || !publicClient || !address || !chainId || !scanResult) return;
    setSweeping(true);
    setDone(false);
    setLog([]);

    const tokensToSweep = scanResult.tokens.filter((t) => selected.has(t.address));

    await sweepAll(
      walletClient,
      publicClient,
      {
        account: address,
        chainId,
        safetyAddress,
        tokens: tokensToSweep,
        nativeBalance: scanResult.nativeBalance,
        reserveForGasWei: RESERVE_FOR_GAS_WEI,
      },
      (event) => {
        setLog((prev) => [...prev, describeEvent(event)]);
        if (event.type === 'done') setDone(true);
      }
    );

    setSweeping(false);
  }

  const nativeToSend =
    scanResult && scanResult.nativeBalance > RESERVE_FOR_GAS_WEI
      ? scanResult.nativeBalance - RESERVE_FOR_GAS_WEI
      : 0n;

  return (
    <div className="panel">
      <h2>Emergency sweep</h2>

      <div className="destination-banner">
        <div className="destination-label">Everything below goes to</div>
        <div className="destination-address">{safetyAddress}</div>
      </div>

      {!scanResult && (
        <button className="btn btn-primary btn-block" disabled={scanning} onClick={handleScan}>
          {scanning ? 'Scanning wallet...' : 'Scan my wallet'}
        </button>
      )}

      {scanResult && !sweeping && !done && (
        <>
          <label className="field-label" style={{ marginTop: 18 }}>
            Native balance
          </label>
          <div className="token-row token-row-native">
            <span>{formatEther(nativeToSend)} native token</span>
            <span className="muted">(reserving gas for the final transfer)</span>
          </div>

          {scanResult.tokens.length > 0 && (
            <>
              <label className="field-label" style={{ marginTop: 14 }}>
                Tokens found ({scanResult.tokens.length})
              </label>
              {scanResult.tokens.map((t) => (
                <label key={t.address} className="token-row token-row-checkbox">
                  <input
                    type="checkbox"
                    checked={selected.has(t.address)}
                    onChange={() => toggleToken(t.address)}
                  />
                  <span>
                    {formatUnits(t.balance, t.decimals)} {t.symbol}
                  </span>
                </label>
              ))}
            </>
          )}
          {scanResult.tokens.length === 0 && (
            <p className="muted" style={{ marginTop: 10 }}>
              No watched tokens found with a balance on this chain.
            </p>
          )}

          <button className="btn btn-danger btn-block" style={{ marginTop: 20 }} onClick={handleSweep}>
            Sweep everything to safety wallet now
          </button>
        </>
      )}

      {(sweeping || log.length > 0) && (
        <div className="log-box">
          {log.map((line, i) => (
            <div key={i} className={line.startsWith('✓') ? 'log-line log-ok' : line.startsWith('✗') ? 'log-line log-err' : 'log-line'}>
              {line}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
