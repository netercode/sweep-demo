import { useState } from 'react';
import { getSafetyAddress, setSafetyAddress, clearSafetyAddress } from '../lib/safetyWallet';
import type { Address } from 'viem';

interface Props {
  onSaved: (address: Address) => void;
}

export function SafetyAddressSetup({ onSaved }: Props) {
  const [input, setInput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const existing = getSafetyAddress();

  function handleSave() {
    try {
      const addr = setSafetyAddress(input.trim());
      setError(null);
      onSaved(addr);
    } catch (err: any) {
      setError(err.message);
    }
  }

  if (existing) {
    return (
      <div className="panel">
        <h2>Safety wallet</h2>
        <p className="muted">
          Funds will always be swept to the address below. This is set once, stored only in your
          own browser, and shown on every screen before anything moves.
        </p>
        <div className="address-box">{existing}</div>
        <button
          className="btn btn-ghost"
          onClick={() => {
            clearSafetyAddress();
            onSaved('' as Address);
          }}
        >
          Change safety wallet
        </button>
      </div>
    );
  }

  return (
    <div className="panel">
      <h2>Set your safety wallet</h2>
      <p className="muted">
        This is a one-time setup. Enter the address you want emergency sweeps to go to — this is
        your address, chosen by you, and it will be visible on every screen from here on. Nothing
        is ever swept anywhere else.
      </p>
      <label className="field-label">Safety wallet address</label>
      <input
        type="text"
        placeholder="0x..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      {error && <div className="msg-err">{error}</div>}
      <button className="btn btn-primary btn-block" onClick={handleSave}>
        Save safety wallet
      </button>
    </div>
  );
}
