import { isAddress, getAddress, type Address } from 'viem';

const STORAGE_KEY = 'safety-sweep:safety-address';

/**
 * The address funds get swept to. This is deliberately the opposite of a
 * hidden/hardcoded destination: it is set by the person using the tool,
 * stored locally in their own browser, and displayed prominently on every
 * screen before any transfer happens. There is no code path that sweeps to
 * an address the user hasn't explicitly set and can't see.
 */
export function getSafetyAddress(): Address | null {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw || !isAddress(raw)) return null;
  return getAddress(raw);
}

export function setSafetyAddress(input: string): Address {
  if (!isAddress(input)) {
    throw new Error('That is not a valid EVM address.');
  }
  const checksummed = getAddress(input);
  localStorage.setItem(STORAGE_KEY, checksummed);
  return checksummed;
}

export function clearSafetyAddress(): void {
  localStorage.removeItem(STORAGE_KEY);
}
