import type { Address } from 'viem';

/** Minimal ERC-20 ABI — only what we need for balance checks and transfers. */
export const erc20Abi = [
  {
    type: 'function',
    name: 'balanceOf',
    stateMutability: 'view',
    inputs: [{ name: 'account', type: 'address' }],
    outputs: [{ name: '', type: 'uint256' }],
  },
  {
    type: 'function',
    name: 'transfer',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'to', type: 'address' },
      { name: 'amount', type: 'uint256' },
    ],
    outputs: [{ name: '', type: 'bool' }],
  },
  {
    type: 'function',
    name: 'decimals',
    stateMutability: 'view',
    inputs: [],
    outputs: [{ name: '', type: 'uint8' }],
  },
  {
    type: 'function',
    name: 'symbol',
    stateMutability: 'view',
    inputs: [],
    outputs: [{ name: '', type: 'string' }],
  },
] as const;

export interface WatchedToken {
  address: Address;
  symbol: string;
}

/**
 * A small built-in watch list per chain, for the demo. This is intentionally
 * simple: in production, replace this with a live portfolio API (Alchemy
 * Portfolio API, Moralis Wallet API, or Dune SIM) so newly-received tokens
 * are discovered automatically instead of relying on a static list.
 *
 * You can also just add addresses here manually for a hackathon demo token
 * you deploy yourself on a testnet.
 */
export const WATCHED_TOKENS: Record<number, WatchedToken[]> = {
  // Sepolia testnet — fill in with your own deployed test token addresses.
  11155111: [],
  // Ethereum mainnet — example: USDC. Add more as needed.
  1: [
    { address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', symbol: 'USDC' },
  ],
};

/**
 * Addresses known to be spam/scam token contracts. Real deployments should
 * pull this from a maintained feed (e.g. a portfolio API's spam flag), but a
 * static blocklist is a reasonable floor for a demo.
 */
export const SPAM_BLOCKLIST = new Set<string>([
  // example entries — replace with a real feed in production
]);

export function isSpamToken(address: Address): boolean {
  return SPAM_BLOCKLIST.has(address.toLowerCase());
}
