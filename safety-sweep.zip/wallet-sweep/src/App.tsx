import { useState } from 'react';
import { useAccount } from 'wagmi';
import type { Address } from 'viem';
import { getSafetyAddress } from './lib/safetyWallet';
import { SafetyAddressSetup } from './components/SafetyAddressSetup';
import { ConnectPanel } from './components/ConnectPanel';
import { SweepPanel } from './components/SweepPanel';

export default function App() {
  const { isConnected } = useAccount();
  const [safetyAddress, setSafetyAddress] = useState<Address | null>(getSafetyAddress());

  return (
    <div className="wrap">
      <header>
        <div className="eyebrow">⟨ Safety Sweep · Emergency Wallet Rescue ⟩</div>
        <h1>SAFETY SWEEP</h1>
        <p className="sub">
          One saved destination. One signature. Every transfer visible before it happens.
        </p>
      </header>

      <SafetyAddressSetup onSaved={(addr) => setSafetyAddress(addr || null)} />

      {safetyAddress && <ConnectPanel />}

      {safetyAddress && isConnected && <SweepPanel safetyAddress={safetyAddress} />}

      <footer>
        This tool only ever moves funds to the safety wallet address shown above, which you set
        yourself. There is no other destination anywhere in this code. Every transfer is signed by
        you, in your own wallet, after you can see exactly what's being sent and where.
      </footer>
    </div>
  );
}
