# Safety Sweep

An emergency EVM wallet sweep tool: connect a wallet, review what's in it,
and move everything — native token + watched ERC-20s, spam filtered out —
to a safety address **you set yourself and can see on every screen**. One
signature when the connected wallet supports EIP-5792 batching, a fast
sequential fallback when it doesn't.

## Why this exists

This started as a "race against a hacker" hackathon pitch: if a wallet is
compromised, speed matters. The fast/convenient version of that idea is
easy to build — the hard, actually-important part is making sure "fast"
never means "the person signing can't see where their funds are going."

Every transfer call in this project targets `safetyAddress` — a value the
user enters once, stored only in their own browser (`localStorage`), shown
in full on the setup screen, the confirmation screen, and the destination
banner right above the sweep button. There is no other destination
anywhere in the code.

## What's actually in here

- **`src/lib/safetyWallet.ts`** — get/set/clear the user's safety address.
  Validated and checksummed with viem. Nothing sweeps anywhere until this
  is set, and it's always rendered on screen.
- **`src/lib/tokens.ts`** — minimal ERC-20 ABI, a per-chain watched token
  list, and a spam blocklist hook.
- **`src/lib/fetchBalances.ts`** — scans native + watched token balances via
  `multicall` (one round trip instead of N).
- **`src/lib/sweep.ts`** — the actual mechanism:
  1. Checks wallet capabilities (`wallet_getCapabilities`, EIP-5792).
  2. If the wallet supports atomic batching, sends every transfer as
     **one signature** (`wallet_sendCalls`).
  3. Otherwise, falls back to signing each transfer sequentially, in order,
     waiting for each confirmation before moving to the next.
- **`src/components/`** — SafetyAddressSetup, ConnectPanel (wagmi
  connectors), SweepPanel (scan → checklist → visible destination banner →
  sweep → live progress log of real transaction events, not decorative
  timers).

## This was actually tested, not just written

`scripts/test-sweep-logic.mjs` spins up a real local chain (Ganache),
compiles and deploys two real ERC-20 contracts, funds a wallet with both
plus native ETH, and runs the **exact `sweepAll()` function the UI calls** —
no mocks, no reimplementation. Run it yourself:

```bash
npm install
npm run test:sweep
```

Last verified run: both tokens and ~99.988 of ~100 starting ETH (the rest
being real gas spent across 3 transactions) ended up in the safety wallet;
the source wallet ended at exactly 0 for both tokens. Since a plain local
node doesn't implement EIP-5792, this run exercises the **sequential
fallback path** — which is also the realistic path today, since wallet
support for batching is still limited (see Known limitations).

This is dev/test-only tooling (`ganache`, `solc`, `tsx` in
devDependencies) — it's not part of the shipped app and isn't in the
production build.

## Setup

```bash
npm install
cp .env.example .env      # optional: add a WalletConnect project ID
npm run dev
```

Open the app, set your safety wallet address, connect a wallet (Sepolia
recommended for testing), and add any test token addresses you want
watched in `src/lib/tokens.ts` under `WATCHED_TOKENS`.

## Known limitations / what to say in the demo

- **Token discovery is a static watch list**, not a live portfolio API.
  For a real deployment, swap `fetchBalances.ts` to call Alchemy's
  Portfolio API, Moralis's Wallet API, or Dune's SIM API so newly-received
  tokens are found automatically instead of needing to be pre-registered.
- **EIP-5792 batch path is implemented but not tested against a real
  wallet in this environment** (no browser wallet extension available in
  the sandbox this was built in). MetaMask, Coinbase Wallet, and Rainbow
  are the wallets most likely to support it as of 2026 — worth testing
  against one of those before a live demo.
- **Spam filtering is a static blocklist**, not a live feed. Fine for a
  demo; swap for a real spam-detection API for anything beyond that.
- **This is not a "provably fair" or trustless mechanism** in the sense a
  smart contract escrow would be — it's a client that signs transactions
  the user explicitly approves, one at a time or as one batch. The
  security property here isn't cryptographic; it's UI honesty (visible
  destination, visible token list, visible per-call progress).

## The pitch

Two clicks: connect wallet, then one signature that sweeps everything
(minus a small gas reserve) to your pre-set safety address. Same speed as
any "one-click drain" concept — the difference is the destination is
yours, chosen by you in advance, and shown on screen the entire time.
